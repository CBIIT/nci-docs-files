package org.bioconductor.packages.caPROcess.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this CaPROcessResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class CaPROcessResource extends CaPROcessResourceBase {

}
