package org.bioconductor.packages.caGeneSetAnalysis.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this CaGeneSetAnalysisResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class CaGeneSetAnalysisResource extends CaGeneSetAnalysisResourceBase {

}
