package org.bioconductor.packages.caGeneSetAnalysis.context.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class CaGeneSetAnalysisContextImpl extends CaGeneSetAnalysisContextImplBase {

	
	public CaGeneSetAnalysisContextImpl() throws RemoteException {
		super();
	}
	
}

