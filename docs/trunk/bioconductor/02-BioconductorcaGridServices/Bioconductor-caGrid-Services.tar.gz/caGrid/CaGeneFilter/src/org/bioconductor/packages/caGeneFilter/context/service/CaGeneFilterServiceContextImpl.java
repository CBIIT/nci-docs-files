package org.bioconductor.packages.caGeneFilter.context.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class CaGeneFilterServiceContextImpl extends CaGeneFilterServiceContextImplBase {

	
	public CaGeneFilterServiceContextImpl() throws RemoteException {
		super();
	}
	
}

