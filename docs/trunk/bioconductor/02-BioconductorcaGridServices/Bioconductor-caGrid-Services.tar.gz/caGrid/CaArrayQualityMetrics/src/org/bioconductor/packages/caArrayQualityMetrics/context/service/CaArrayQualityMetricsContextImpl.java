package org.bioconductor.packages.caArrayQualityMetrics.context.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class CaArrayQualityMetricsContextImpl extends CaArrayQualityMetricsContextImplBase {

	
	public CaArrayQualityMetricsContextImpl() throws RemoteException {
		super();
	}
	
}

