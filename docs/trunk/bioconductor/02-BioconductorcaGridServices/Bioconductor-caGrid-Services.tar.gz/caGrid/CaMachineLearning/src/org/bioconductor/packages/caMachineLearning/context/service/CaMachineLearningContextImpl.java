package org.bioconductor.packages.caMachineLearning.context.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class CaMachineLearningContextImpl extends CaMachineLearningContextImplBase {

	
	public CaMachineLearningContextImpl() throws RemoteException {
		super();
	}
	
}

