
/*********Inserting Any value in storage type tables********/
insert into catissue_container_type (IDENTIFIER,CAPACITY_ID,NAME,ONE_DIMENSION_LABEL,TWO_DIMENSION_LABEL,COMMENTS,ACTIVITY_STATUS) values ( '1',NULL,'All',NULL,NULL,NULL,'Disabled');
insert into catissue_container_type (IDENTIFIER,CAPACITY_ID,NAME,ONE_DIMENSION_LABEL,TWO_DIMENSION_LABEL,COMMENTS,ACTIVITY_STATUS) values ( '2',NULL,'Any',NULL,NULL,NULL,'Disabled');
insert into catissue_storage_type (IDENTIFIER) values ( '1');
insert into catissue_specimen_array_type (IDENTIFIER) values ( '2');
