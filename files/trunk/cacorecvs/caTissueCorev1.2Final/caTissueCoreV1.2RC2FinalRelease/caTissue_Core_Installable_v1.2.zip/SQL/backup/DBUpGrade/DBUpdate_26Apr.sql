/*Mandar : 26-Apr-06 : Changes as per bug 874. Title width increased to 150. */
/* SQL tested on MySQL */
alter table catissue_specimen_protocol ,change `TITLE` `TITLE` varchar (150)   NOT NULL 