
       
       #!/bin/sh
       java -Xmx512m -jar FileSender.jar
        
    