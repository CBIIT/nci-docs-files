#!/bin/sh
ps -ef | grep java | grep tomcat5 | grep jai_imageio-1_1 | awk '{print "kill -9 " $2}' | sh
