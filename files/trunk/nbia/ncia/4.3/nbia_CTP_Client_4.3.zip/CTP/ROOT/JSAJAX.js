//Functions to provide AJAX support

function getXmlHttp() {
	var req = null;

	if (window.XMLHttpRequest) req = new XMLHttpRequest();

	else if (window.ActiveXObject) req = new ActiveXObject("Microsoft.XMLHTTP");

	if (req) {
		req.success = function() { return req.isReady() && req.isOK(); };
		req.isReady = function() { return (req.readyState == 4); };
		req.isOK = function() { return (req.status == 200); };
		req.timeStamp = function() { return "timeStamp=" + new Date().getTime(); };

		req.GET =
			function(url, qs, handler) {
				var async = (handler != null);
				req.open("GET", url + (qs ? "?"+qs : ""), async);
				if (async) req.onreadystatechange = function() { handler(req); };
				req.send(null);
			};

		req.POST =
			function(url, qs, handler) {
				var async = (handler != null);
				req.open("POST", url, true);
				if (async) req.onreadystatechange = function() { handler(req); };
				req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				req.send(qs);
			};
	}
	return req;
}
