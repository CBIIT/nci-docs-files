//Menu Package

//some global parameters
var popupZIndex = 40;
var menuZIndexMax = 30;
var menuZIndexMin = 20;
var inMenu = false;
var menuTimeout = 1000;
var menuTimeoutId = null;
var menuTimerRunning = false;

//****** The MenuBar class ******
//
//There can be only one MenuBar instance in the window,
//and it must be stored in a var named "menuBar".
function MenuBar(id, menus) {
	this.menus = menus;
	this.id = id; 		//the id of the MenuBar div
	inMenu = false;
	this.setPointers(); //set the pointers so everybody knows who's who.
}

MenuBar.prototype.setPointers = function() {
	//Note: the index is an object containing properties
	//for all Items which have name properties. This is
	//intended to allow a program to find a specific
	//Item without having to know where it has been placed
	//in the menu system.
	//
	//This function builds the index and also sets up
	//the pointers so that all items know who their
	//parents are.
	//
	//This function must be called immediately after
	//a change is made to the menuBar or any of its
	//menus. Failure to do so may result in handlers
	//not being able to navigate their menus.
	this.index = new Object();
	for (var i=0; i<this.menus.length; i++) {
		this.menus[i].setPointers(this.index, this.menus[i]);
	}
}

MenuBar.prototype.display = function() {
	var div = document.getElementById(this.id);
	if (div) {
		div.className = "MenuBar";
		div.isMenuSystemDiv = true;
		div.onmouseout = checkHideMenus;
		div.onmousein = setInMenu;
		//remove all the children
		while (div.firstChild) div.removeChild(div.firstChild);
		//put in the menu titles
		var hasMenu = false;
		for (var i=0; i<this.menus.length; i++) {
			if (this.menus[i].enabled) {
				if (hasMenu) div.appendChild(document.createTextNode("\u00A0\u00A0\u00A0|\u00A0\u00A0\u00A0"));
				var s = document.createElement("SPAN");
				s.appendChild(document.createTextNode(this.menus[i].title));
				s.onmouseover = highlight;
				s.onmouseout = dehighlight;
				s.onmouseenter = menuTitleClicked; //autodisplay
				s.onclick = menuTitleClicked;
				s.item = this.menus[i];
				div.appendChild(s);
				hasMenu = true;
			}
		}
	}
}
//****** End of the MenuBar class ******

//****** The Menu class ******
function Menu(title, items, name) {
	this.title = title;
	this.items = items;
	this.name = name;
	this.enabled = true;
}

Menu.prototype.setPointers = function(index, parentMenu) {
	if ((this.name != null) && (this.name != "")) index[this.name] = this;
	this.parentMenu = parentMenu;
	for (var i=0; i<this.items.length; i++) {
		this.items[i].setPointers(index, this);
	}
}

Menu.prototype.replaceItem = function(newItem, oldItem) {
	for (var i=0; i<this.items.length; i++) {
		if (this.items[i] == oldItem) {
			this.items[i] = newItem;
			return;
		}
	}
}

Menu.prototype.display = function(x, y, submenu, zIndex) {
	this.zIndex = zIndex;
	var div = document.createElement("DIV");
	div.className = "Menu";
	if (submenu) div.style.paddingLeft = 0;
	div.isMenuSystemDiv = true;
	div.onmouseout = checkHideMenus;
	div.style.left = x;
	div.style.top = y;
	div.style.zIndex = zIndex;
	var firstItem = true;
	for (var i=0; i<this.items.length; i++) {
		var item = this.items[i];
		if (item.enabled) {
			if ((item.title == null) || (item.title == "")) {
				var hr = document.createElement("HR");
				if (submenu) hr.style.marginLeft = 15;
				div.appendChild(hr);
			}
			else {
				if (submenu) {
					var s = document.createElement("SPAN");
					s.className = "larr";
					s.appendChild(document.createTextNode( (firstItem ? "\u00AB" : "") ));
					div.appendChild(s);
				}
				var s = document.createElement("SPAN");
				s.appendChild(document.createTextNode(item.title));
				if ((item instanceof Menu) || (item.handler)) {
					s.onmouseover = highlight;
					s.onmouseout = dehighlight;
					s.onclick = menuItemClicked;
					s.item = item;
				}
				else s.className = "unselectable";
				if (item instanceof Menu) {
					s.onmouseenter = menuItemClicked; //autodisplay
				}
				div.appendChild(s);
				div.appendChild(document.createElement("BR"));
			}
			firstItem = false;
		}
	}
	removeZRange(menuZIndexMin, zIndex);
	document.body.appendChild(div);
	inMenu = true;
}
//****** End of the Menu class ******

//****** The Item class ******
function Item(title, handler, name) {
	this.title = title;
	this.handler = handler;
	this.name = name;
	this.enabled = true;
}

Item.prototype.setPointers = function(index, parentMenu) {
	if ((this.name != null) && (this.name != "")) index[this.name] = this;
	this.parentMenu = parentMenu;
}
//****** End of the Item class ******

//****************** Important handlers *******************

//This handler catches the timeout for hiding the menus
//when the mouse has moved to a non-menu part of the
//screen.
function menuTimeoutHandler(event) {
	stopMenuTimer();
	if (!inMenu) removeMenus();
}

//This handler catches the onmousein event and sets
//the flag indicating that the cursor is over a menu
function setInMenu(event) {
	event = getEvent(event);
	var source = getSource(event);
	var sourceDiv = source;
	while ((sourceDiv != null) && (sourceDiv.tagName != "DIV")) sourceDiv = sourceDiv.parentNode;
	if (sourceDiv != null) inMenu = sourceDiv.isMenuSystemDiv;
	else alert("sourceDiv is null");
}

//This handler catches the click on a menu title
//in the MenuBar. It gets the MenuBar and the Menu
//from the menu title and calls the MenuBar to
//display the menu.
function menuTitleClicked(event) {
	event = getEvent(event);
	var source = getSource(event);
	var menu = source.item.parentMenu;
	var pos = findObject(source);
	removeMenus();
	var x = pos.x - 15;
	var y = pos.y + pos.h + (document.all ? 3 : 4);
	menu.display(x, y, false, menuZIndexMax);
}

//This handler catches the click on a menu item
//in a Menu. It gets the Item and handles it.
//
//If the handler specified for the item is null,
//it does nothing.
//
//If the handler is a menu, it displays the
//menu as a submenu, and leaves all higher-level
//menus in place.
//
//Otherwise, it hides all the menus and then
//calls the specified handler, passing the
//event and the item.
function menuItemClicked(event) {
	event = getEvent(event);
	var source = getSource(event);
	var item = source.item;
	if (item instanceof Menu) {
		var srcpos = findObject(source);
		var sourceDiv = source;
		while ((sourceDiv != null) && (sourceDiv.tagName != "DIV")) sourceDiv = sourceDiv.parentNode;
		var divpos = findObject(sourceDiv);
		var menu = source.item.parentMenu;
		var x = divpos.x + divpos.w -1;
		var y = srcpos.y -4;
		var z = item.parentMenu.zIndex - 1;
		item.display(x, y, true, z);
	}
	else {
		removeMenus();
		if (item.handler != null) item.handler(event, item);
	}
}

//Handle the onmouseout for a MenuBar div or a Menu div,
//and determine whether it is necessary to hide the menus.
function checkHideMenus(event) {
	event = getEvent(event);
	var source = getSource(event);
	var dest = getDestination(event);

	//Find the source DIV.
	var sourceDiv = source;
	while ((sourceDiv != null) && (sourceDiv.tagName != "DIV")) sourceDiv = sourceDiv.parentNode;
	var sourceIsMenuSystemDiv = (sourceDiv != null) && sourceDiv.isMenuSystemDiv;

	//Find the destination DIV
	var destDiv = dest;
	while ((destDiv != null) && (destDiv.tagName != "DIV")) destDiv = destDiv.parentNode;
	var destIsMenuSystemDiv = (destDiv != null) && destDiv.isMenuSystemDiv;

	//See if we are leaving the menu system
	if (sourceIsMenuSystemDiv && !destIsMenuSystemDiv) {
		startMenuTimer();
		inMenu = false;
	}
	else inMenu = true;
}

//This handler catches the onmouseover event
//for menu titles and items and sets the
//className to highlight them.
function highlight(event) {
	event = getEvent(event);
	var source = getSource(event);
	source.className = "highlight";
}

//This handler catches the onmouseout event
//for menu titles and items and sets the
//className to dehighlight them.
function dehighlight(event) {
	event = getEvent(event);
	var source = getSource(event);
	source.className = "dehighlight";
}

//*************************** Timer functions ***************************

function startMenuTimer() {
	stopMenuTimer();
	menuTimeoutId = window.setTimeout(menuTimeoutHandler, menuTimeout);
	menuTimerRunning = true;
}

function stopMenuTimer() {
	if (menuTimerRunning) {
		window.clearTimeout(menuTimeoutId);
		menuTimerRunning = false;
	}
}

//*************************** Useful functions ***************************

function removeMenus() {
	inMenu = false;
	stopMenuTimer();
	removeZRange(menuZIndexMin, menuZIndexMax);
}

function removeZRange(lowerZIndex, upperZIndex) {
	var divs = document.getElementsByTagName("DIV");
	for (var i=divs.length-1; i>=0; i--) {
		var z = divs[i].style.zIndex;
		if ((z >= lowerZIndex) && (z <= upperZIndex)) {
			divs[i].parentNode.removeChild(divs[i]);
		}
	}
}

function hideZRange(lowerZIndex, upperZIndex) {
	var divs = document.getElementsByTagName("DIV");
	for (var i=divs.length-1; i>=0; i--) {
		var z = divs[i].style.zIndex;
		if ((z >= lowerZIndex) && (z <= upperZIndex)) {
			divs[i].style.visibility = "hidden";
			divs[i].style.display = "none";
		}
	}
}

//************************* Popup Functions **************************

//Display a popup, more or less centered in the visible area.
function showPopup(popupDivId, w, h, heading, closeboxFile) {
	removeMenus();
	hidePopups();
	var bodyPos = findObject(document.body);
	var menubarPos = findObject(document.getElementById(menuBar.id));
	var x = (bodyPos.w - w) / 2;
	var menubarBottom = menubarPos.y + menubarPos.h;
	var extraSpace = bodyPos.h - menubarBottom - h
	var y = menubarBottom + extraSpace / 3;
	if (y < 0) y = 0;
	var popup = document.getElementById(popupDivId);
	setPopupTitleBar(popup, heading, closeboxFile);
	popup.style.width = w;
	popup.style.height = h;
	popup.style.left = x;
	popup.style.top = y;
	popup.style.visibility = "visible";
	popup.style.display = "block";
	popup.style.overflow = "auto";
	popup.style.zIndex = popupZIndex;
}

//Display a popup frame and load it from a URL
function showPopupFrame(id, w, h, frId, frURL, heading, closeboxFile) {
	showPopup(id, w, h, heading, closeboxFile);
	var frame = document.getElementById(frId);
	frame.style.width = w - 30;
	frame.style.height = h - 55;
	window.open(frURL, frId);
}

//Hide all popups
function hidePopups() {
	hideZRange(popupZIndex, popupZIndex);
}

//Insert a titlebar if a popup doesn't already have one
function setPopupTitleBar(popup, heading, closeboxFile) {
	//find the first non-TextNode child
	var child = popup.firstChild;
	while ((child != null) && (child.nodeType == 3)) child = child.nextSibling;
	if ((child.tagName != "DIV") || (child.className != "titlebar")) {
		var titlebar = document.createElement("DIV");
		titlebar.className = "titlebar";
		titlebar.onmousedown = startPopupDrag;
		var closebox = document.createElement("DIV");
		closebox.className = "closebox";
		var img = document.createElement("IMG");
		img.setAttribute("src", closeboxFile);
		img.setAttribute("title", "Close");
		img.onclick = hidePopups;
		closebox.appendChild(img);
		titlebar.appendChild(closebox);
		heading = ( (heading == null) || (heading == "")) ? "\u00A0" : heading;
		var title = document.createElement("P");
		title.appendChild(document.createTextNode(heading));
		titlebar.appendChild(title);
		popup.insertBefore(titlebar, popup.firstChild);
	}
}

//This handler starts the drag of a popup.
function startPopupDrag(event) {
	//Find the node to drag. This handler assumes that the onmousedown
	//event occurred in a popup titlebar, which must be a first-generation
	//child of the popup div to be dragged.
	event = getEvent(event);
	var node = getSource(event);
	//Find the DIV (it may be a level or so above the source node,
	//if the user happened to click on the title text in the titlebar).
	while ((node != null) && (node.tagName != "DIV")) node = node.parentNode;
	if ((node != null) && (node.className == "titlebar")) {
		//This must be the titlebar; start dragging its parent.
		dragPopup(node.parentNode, event);
	}
}

//Drag and drop a popup
function dragPopup(node, event) {
	deltaX = event.clientX - parseInt(node.style.left);
	deltaY = event.clientY - parseInt(node.style.top);
	if (document.addEventListener) {
		document.addEventListener("mousemove", dragIt, true);
		document.addEventListener("mouseup", dropIt, true);
	}
	else {
		node.attachEvent("onmousemove", dragIt);
		node.attachEvent("onmouseup", dropIt);
		node.setCapture();
	}
	if (event.stopPropagation) event.stopPropagation();
	else event.cancelBubble = true;
	if (event.preventDefault) event.preventDefault();
	else event.returnValue = false;

	function dragIt(evt) {
		if (!evt) evt = window.event;
		node.style.left = (evt.clientX - deltaX) + "px";
		node.style.top = (evt.clientY - deltaY) + "px";
		if (evt.stopPropagation) event.stopPropagation();
		else evt.cancelBubble = true;
	}

	function dropIt(evt) {
		if (!evt) evt = window.event;
		if (document.addEventListener) {
			document.removeEventListener("mouseup", dropIt, true);
			document.removeEventListener("mousemove", dragIt, true);
		}
		else {
			node.detachEvent("onmousemove", dragIt);
			node.detachEvent("onmouseup", dropIt);
			node.releaseCapture();
		}
		if (evt.stopPropagation) event.stopPropagation();
		else evt.cancelBubble = true;
	}
}

//************************* Dialog Popup Functions **************************
//
function showTextDialog(popupDivId, w, h, heading, closeboxFile, title, text, okHandler, cancelHandler) {
	var popup = document.getElementById(popupDivId);
	if (!popup) {
		var div = document.createElement("DIV");
		var p = document.createElement("P");
		p.className = "indentedblock";
		p.appendChild(document.createTextNode(text));
		div.appendChild(p);
		showDialog(popupDivId, w, h, heading, closeboxFile, title, div, okHandler, cancelHandler);
	}
	else showPopup(popupDivId, w, h, heading, closeboxFile);
}

function showDialog(popupDivId, w, h, heading, closeboxFile, title, div, okHandler, cancelHandler) {
	var popup = document.getElementById(popupDivId);
	if (!popup) {
		//The popup does not exist, create it.
		popup = document.createElement("DIV");
		popup.id = popupDivId;
		popup.className = "popup";

		var content = document.createElement("DIV");
		content.className = "content";
		popup.appendChild(content);

		var h1 = document.createElement("H1");
		h1.appendChild(document.createTextNode(title));
		content.appendChild(h1);

		content.appendChild(div);

		p = document.createElement("P");
		p.className = "centeredblock";
		content.appendChild(p);

		var button = document.createElement("INPUT");
		button.className = "stdbutton";
		button.type = "button";
		button.value = "OK";
		button.onclick = okHandler ? okHandler : hidePopups;
		p.appendChild(button);

		if (cancelHandler) {
			p.appendChild(document.createTextNode("\u00A0\u00A0\u00A0"));

			button = document.createElement("INPUT");
			button.className = "stdbutton";
			button.type = "button";
			button.value = "CANCEL";
			button.onclick = cancelHandler;
			p.appendChild(button);
		}

		document.body.appendChild(popup);
	}
	showPopup(popupDivId, w, h, heading, closeboxFile);
}
